/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: PascalsTriangleGenerator.java
 * Author: Java Foundation
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartD;



public class PascalsTriangleGenerator {

    public PascalsTriangleGenerator() {
    }

    public int[] computeRow(int numberOfRow) {
        //numberOfRow is equal to the real world index
        numberOfRow= numberOfRow-1;
        int[] array = new int[numberOfRow+1];
        //int end = numberOfRow+1;
        for (int index=0;index<numberOfRow+1;index++) {
            array[index] =designTriangle(numberOfRow, index);


        }
        return array;
    }

    private int designTriangle(int numberOfRow, int index) {

        /*
        *
        *
        *
        *
         0 1 2 3  4  5 6

    0    1
    1    1 1
    2    1 2 1
    3    1 3 3  1
    4    1 4 6  4  1
    5    1 5 10 10 5 1
    6    1 6 1 20 15 6 1


        * * */


        if ((index==0)||(index == numberOfRow)){
            return 1;

        }else{

            return designTriangle(numberOfRow-1,index)+designTriangle(numberOfRow-1,index-1);
        }

    }
}
