/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: BlurbGenerator.java
 * Author: Java Foundation
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartC;
public class BlurbGenerator {

    /**
     * Instantiates a random number generator needed for blurb creation.
     */
    public BlurbGenerator() {
    }

    /**
     * Generates and returns a random Blurb. A Blurb is a Whoozit followed by
     * one or more Whatzits.
     */
    public String makeBlurb() {
        int WhoozitNumber = (int) (Math.random() * 10)+1;
        int WhatzitNumber=(int) (Math.random() * 10)+1;
        return  makeWhoozit(WhoozitNumber)+makeWhatzit(WhatzitNumber);


    }

    /**
     * Generates a random Whoozit. A Whoozit is the character 'x' followed by
     * zero or more 'y's.
     */
    private String makeWhoozit(int number) {
        String x = "x";
        //String y = "y";
        String xy=makeYString(number);


        return x+xy;
    }

    /**
     * Recursively generates a string of zero or more 'y's.
     */

    private String makeYString(int number) {
        String xy="y";
        if (number == 1) {
            return "y";
        } else {
            xy=makeYString(number-1)+xy;
        }return xy;
    }

    /**
     * Recursively generates a string of one or more Whatzits.
     */

    private String makeMultiWhatzits(int number) {
        String what;
        int number1= (int) (Math.random() * 3)+1;
        if(number1%2==1){
            what =makeWhoozit(number);

        }else {
            what = makeMultiWhatzits(number - 1) + makeWhatzit(number);
        }
        return what;
    }

    /**
     * Generates a random Whatzit. A Whatzit is a 'q' followed by either a 'z'
     * or a 'd', followed by a Whoozit.
     */

    private String makeWhatzit(int number) {
        //int number= (int) (Math.random()+1)*20;
        String dz;
        if (number%2==1) {
            dz= "z";
        }else {
            dz=  "d";
        }
        int number1=(int) ( Math.random()+1)*6;

        return "q"+dz+makeMultiWhatzits(number1);
    }

}